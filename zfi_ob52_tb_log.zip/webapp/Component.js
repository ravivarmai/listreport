sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("com.autodesk.zfi_ob52_tb_log.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});